public class MallardDuck extends Duck{
    public MallardDuck(QuackBehaviour quackBehaviour, FlyBehaviour flyBehaviour) {
        super(quackBehaviour, flyBehaviour);
    }
}
