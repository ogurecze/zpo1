public class FakeDuck extends Duck{
    public FakeDuck(QuackBehaviour quackBehaviour, FlyBehaviour flyBehaviour) {
        super(quackBehaviour, flyBehaviour);
    }
}
