public interface FlyBehaviour {
     void fly();
}
