public interface QuackBehaviour {
   void quack();
}
