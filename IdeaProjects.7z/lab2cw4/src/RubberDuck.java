public class RubberDuck extends Duck{
    public RubberDuck(QuackBehaviour quackBehaviour, FlyBehaviour flyBehaviour) {
        super(quackBehaviour, flyBehaviour);
    }
}
