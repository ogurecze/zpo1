public class FlyWithWings implements FlyBehaviour {
    @Override
    public void fly() {
        System.out.println("lot lot");
    }
}
