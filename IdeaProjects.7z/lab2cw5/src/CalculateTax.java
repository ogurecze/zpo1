public interface CalculateTax {
    public String calculate();
}
