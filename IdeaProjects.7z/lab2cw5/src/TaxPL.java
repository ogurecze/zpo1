public class TaxPL implements CalculateTax{
    @Override
    public String calculate() {
        return "tax for PL";
    }
}
