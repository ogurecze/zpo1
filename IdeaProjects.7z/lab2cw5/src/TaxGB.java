public class TaxGB implements CalculateTax{
    @Override
    public String calculate() {
        return "tax for GB";
    }
}
