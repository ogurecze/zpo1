public class Shop {
    Shop(){
        System.out.printf("kupuje kupuje");
    }
    public String doCalculate(Client client){
        return client.calculateTax.calculate();
    }
}
