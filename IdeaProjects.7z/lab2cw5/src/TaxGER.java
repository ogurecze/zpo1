public class TaxGER implements CalculateTax{
    @Override
    public String calculate() {
        return "tax for GER";
    }
}
