public class Main {
    public static void main(String[] args) {
        Pracownik pracownik = new Pracownik("Ciesla");
    }
}