public interface Dojezdzac {
    void dojezdzaj();
}
