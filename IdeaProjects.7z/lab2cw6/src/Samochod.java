public class Samochod implements Dojezdzac{
    @Override
    public void dojezdzaj() {
        System.out.printf("jestem samochodem");
    }
}
