public class Leczenie implements Pracowac{
    @Override
    public void pracuj() {
        System.out.println("lecz sie");
    }
}
