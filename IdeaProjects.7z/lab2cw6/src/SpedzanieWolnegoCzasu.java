public interface SpedzanieWolnegoCzasu {
    void spedzajWolnyCzas();
}
