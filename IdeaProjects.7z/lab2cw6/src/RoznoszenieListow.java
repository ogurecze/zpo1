public class RoznoszenieListow implements Pracowac{
    @Override
    public void pracuj() {
        System.out.println("roznosze roznosze");
    }
}
