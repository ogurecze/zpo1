public class Rower implements Dojezdzac{
    @Override
    public void dojezdzaj() {
        System.out.printf("jestem rowerem");
    }
}
