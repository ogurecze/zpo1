public class Silownia implements SpedzanieWolnegoCzasu{
    @Override
    public void spedzajWolnyCzas() {
        System.out.printf("pakuje pakuje");
    }
}
